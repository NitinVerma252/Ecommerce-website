SHOPEASE - FRONTEND E-COMMERCE DEMO

Files:
- index.html: Complete website (HTML, CSS, JavaScript in one file)
- vercel.json: Static deployment configuration

Run locally:
1. Open index.html in a browser.

Deploy to Vercel:
1. Upload this folder to a GitHub repository.
2. In Vercel, choose Add New -> Project and import the repository.
3. Framework Preset: Other
4. Build Command: leave empty
5. Output Directory: .
6. Click Deploy.

Notes:
- This is a frontend-only student demo.
- Products, cart, wishlist, demo orders and admin product changes are stored in browser LocalStorage.
- Checkout is simulated. No real payment, authentication, server or shared database is included.
- Product images are loaded from Unsplash and need internet access.
